# List of names
names = ["Harry", "Ron", "Hermione", "Ginny"]

# Print first name
print(names[0])

# Add a new name
names.append("Draco")

# Sort names alphabetically
names.sort()

# Print list of names
print(names)
