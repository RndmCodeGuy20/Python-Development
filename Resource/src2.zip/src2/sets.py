# Create an empty set
s = set()

# Add elements to set
s.add(1)
s.add(3)
s.add(5)
s.add(3)
print(s)

# Remove elemnt from set
s.remove(5)
print(s)
